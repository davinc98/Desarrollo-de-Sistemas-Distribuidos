/*
    Autor: Perez Federico Jose Joel
    Fecha: 01-03-2021
    Grupo: 4CM3
    Materia: Desarrollo de Sistemas Distribuidos
    Programa: Calculo Distribuido de PI
 */

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author J.Perez
 */
public class PI {

    static Object lock = new Object();
    static double pi = 0;

    static class Worker extends Thread {

        Socket conexion;

        Worker(Socket conexion) {
            this.conexion = conexion;
        }

        public void run() {
            try {
                //ALGORITMO 1
                //1-Streams de entrada y salida
                DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                DataInputStream entrada = new DataInputStream(conexion.getInputStream());

                //2-Variable x de tipo double
                double x = entrada.readDouble();;

                //3-Recibir en la variable x de la suma calculada
                //4-En un bloque synchronized mediante el objecto lock
                synchronized (lock) {
                    pi += x;
                }

                //5-Cerrar los streams de entrada y salida
                salida.close();
                entrada.close();

                //6-Cerrar la conexion
                conexion.close();

            } catch (IOException ex) {
                System.out.println("Error en worker. " + ex);
            }

        }
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        if (args.length != 1) {
            System.err.println("Uso:");
            System.err.println("java PI <nodo>");
            System.exit(0);
        }

        int nodo = Integer.valueOf(args[0]);
        if (nodo == 0) {//NODO SERVIDOR
            //ALGORITMO 2
            //1-Declarar una variable "servidor" de tipo ServerSocket
            ServerSocket servidor;
            
            //2-Crear un socket servidor utilizando el puerto 50000 y asignarlo
            //a la variable "servidor"
            servidor = new ServerSocket(50000);
            
            //3-Declarar un vector "w" de tipo Worker con 4 elementos
            Worker[] w = new Worker[4];
            
            //4-Declarar una variable entera "i" y asignarle cero
            int i=0;
            
            //5-En un ciclo
            //5.1-Si la variable "i" es igul a 4, entonces salir del ciclo
            for (i = 0; i < 4; i++) {
                //5.2-Declarar una variable "conexion" de tipo socket
                //5.3-Invocar el metodo servidor.accept() y asignar el resultado a la variable socket
                Socket conexion = servidor.accept();
                //Guardamos el socket de la coneccion del cliente
                //5.4-Crear una instancia de la clase Worker, pasando como parametro la variable "conexion"
                //          Asignar la instancia al elemento w[i].
                w[i] = new Worker(conexion);
                //5.5-Invocar al metodo w[i].start()                
                w[i].start();
            }
            
            //6-Declarar una variable "i" entera y asignarle cero
            i=0;
            //7-En un ciclo:
            //7.1-Si la variable "i" entera es igual a 4, salir del ciclo
            //7.2-Invocar el metodo w[i].join()
            //7.3-Incrementar la variable "i"
            //7.4-Ir al paso 7.1
            for (i = 0; i < 4; i++) {
                w[i].join();
            }
            
            //8-Desplegar el valor de la variable "pi"
            System.out.println("El valor de pi es; " + pi);
            
        } else {//NODO CLIENTE
            //ALGORITMO 3

            //1-Declarar la variable "conexion" de tipo Socket y asignarle null
            Socket conexion = null;

            //2-Realizar la conexion con el servidor implementando re-intento.Asignar el socket a la variable "conexion" 
            for (;;) {
                try {
                    conexion = new Socket("localhost", 50000);
                    break;
                } catch (Exception e) {
                    Thread.sleep(100);
                }
            }
            
            //3-Crear los streams de entrada y salida.
            DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
            DataInputStream entrada = new DataInputStream(conexion.getInputStream());
            
            //4-Declarar la variable "suma" de tipo double y asignarle cero.
            double suma = 0;
            
            //6-En un ciclo, si el contador llega a 10000000 salir del ciclo
            for (int i = 0; i < 10000000; i++) {
                //6.2-Asignar a la variable "suma" la expresion:
                suma += 4.0 / (8 * i + 2 * (nodo - 2) + 3);
            }
            
            //7-Asignar a la variable "suma" la expresion:
            suma = nodo % 2 == 0 ? -suma :suma;

            //8-Enviar el valor de la variable "suma"
            salida.writeDouble(suma);
            //9-Cerramos los streams de entrada y salida
            salida.close();
            entrada.close();
            //10-Cerrar la conexión
            conexion.close();
        }
    }

}
